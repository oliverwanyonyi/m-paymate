const express = require('express');
const app = express();
const port = 3001;
const sequelize = require('./models/Index');
const db = require('./models/Index')
const cors = require('cors')
const authRoutes = require('./routes/authRoutes')






  app.use(
    cors({
     origin:["http://localhost:3000", "https://shopyetu.netlify.app"],
      credentials: true,
    })
  )

app.use(express.json());

app.use('/api', authRoutes);


db.sequelize
  .sync()
  .then(() => {
    console.log("Synced db.")
    app.listen(3001, () => {
      console.log("Server is running on port 3001.")
    })
  })
  .catch((err) => {
    console.log("Failed to sync db: " + err.message)
  })