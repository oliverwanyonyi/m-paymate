const router = require('express').Router()
const { register } = require('../controllers/authController')
const {login} = require('../controllers/authController.js')

router.route('/login').post(login)

router.post('/register',register)


module.exports = router