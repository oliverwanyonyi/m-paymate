const bcrypt = require('bcryptjs');
const db = require('../models/Index')
const User = db.User
const register = async(req,res) =>{
      
  const { name, phone, email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const userExists = await User.findOne({where:{email}})
  if(userExists){
    return res.json({success:false,message:'user with that email already exists'})
  }
  const newUser = await User.create({ name, email, password:hashedPassword,phone });
  res.json({ success: true ,user:newUser});
}


const login  = async (req,res) =>{

   
    const { email, password } = req.body;
  
    const user = await User.findOne({ where: { email:email } });
    if (!user) {
      return res.json({ success: false, message: 'User not found' });
    }
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.json({ success: false, message: 'Invalid password' });
    }
    res.json({ success: true, user });

}

module.exports = {login,register}